import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceComponent } from '../auth-service/auth-service.component';
import { User } from '../User';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user : User;
  submitted: boolean = false;
  err : boolean;
  msg : string;
  constructor(private service : AuthServiceComponent, private router: Router) {
    this.user = {
      id : "",
      name : "",
      email : "",
      password : "",
      address : [],
      prof : "",
      phone : 0
    } 
    this.msg ="";
    this.err = false;
  }

  ngOnInit(){ 
    localStorage.removeItem("user_id");
    localStorage.removeItem("user_name");
    localStorage.removeItem("username");
    localStorage.removeItem("cartitems");
  }

  onSubmit(){
    this.submitted = true;

    this.service.loginUser(this.user).subscribe(
      (data : any) => {
        if(data[0].password == this.user.password){
          this.service.isUserLoggedIn= true;
          localStorage.setItem('user', JSON.stringify(data));
          this.router.navigate(['/home']);
        }else{
          this.service.isUserLoggedIn= false;  
          this.msg = "Invalid username/password"; 
          this.err = true;       
        }                  
    });
  }

}
