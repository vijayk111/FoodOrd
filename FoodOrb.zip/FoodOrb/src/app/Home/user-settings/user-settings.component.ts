import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceComponent } from 'src/app/Authentication/auth-service/auth-service.component';
import { Address, User } from 'src/app/Authentication/User';
import { HomeServiceComponent } from '../home-service/home-service.component';

@Component({
  selector: 'app-user-settings',
  templateUrl: './user-settings.component.html',
  styleUrls: ['./user-settings.component.css']
})
export class UserSettingsComponent implements OnInit {

  isUserLoggedIn : boolean;
  user : User;
  address : Address[];
  adClass : Address;
  constructor(private service : HomeServiceComponent, private router : Router,
    private authService : AuthServiceComponent) { 
    this.isUserLoggedIn = authService.isUserLoggedIn;
    this.user = JSON.parse(localStorage.getItem('user') || '{}')[0];
    this.address = this.user.address;
    console.log(this.user);    
    this.adClass = new Address();    
  }

  ngOnInit() {
  }

  showDiv = {
    card : false,
    address : false
  }

  showAddressDiv = {
    list : true,
    addAds : false
  }

  showAEditdiv = {
    editAd : false
  }

  onAdSubmit(){
    this.user.address.push(this.adClass);    
    this.showAddressDiv.list = true;
    this.showAddressDiv.addAds=false;
    return this.service.addAddress(this.user);
  }

  onEditSubmit(){
    this.user.address.push(this.adClass);    
    this.showAddressDiv.list = true;
    this.showAddressDiv.addAds=false;
    this.showAEditdiv.editAd =false;
    return this.service.addAddress(this.user);
  }

  routeDelete(){
    this.router.navigate(['home']);
  }
}
