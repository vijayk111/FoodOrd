import { Component, OnInit } from '@angular/core';
import { AuthServiceComponent } from 'src/app/Authentication/auth-service/auth-service.component';
import { User } from 'src/app/Authentication/User';
import { HomeServiceComponent } from '../home-service/home-service.component';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  user : User;
  isUserLoggedIn : boolean;
  constructor(private service : HomeServiceComponent,
    private authService : AuthServiceComponent) { 
    this.isUserLoggedIn = authService.isUserLoggedIn;
    this.user = JSON.parse(localStorage.getItem('user') || '{}')[0];
  }

  ngOnInit(): void {
  }

}
