import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../Authentication/User';
import { HomeServiceComponent } from './home-service/home-service.component';
import { CartItem, Item } from './Item';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  users : any;
  user : User;
  items : Item[];
  isSearch : boolean; 
  isUserLoggedIn : boolean;
  sResult : boolean;
  searching : boolean;
  searchitem : string ;
  cartItem : CartItem;
  constructor(private service : HomeServiceComponent, private router : Router) {    
    this.users = JSON.parse(localStorage.getItem('user') || '{}'); 
    this.user = this.users[0];  
    this.isSearch = false; 
    this.items = []; 
    this.isUserLoggedIn = false;
    this.searchitem = "";
    this.sResult = true;
    this.searching = false;
    this.cartItem = new CartItem();
    this.cartItem.user_id = "";
    this.cartItem.items = [];    
  }

  ngOnInit(){
    this.isSearch = this.service.isSearch; 
    this.isUserLoggedIn = true;  
    if(!this.searching){
      this.service.getAllItems().subscribe((data : any) =>{
        this.items = data;
      });
    }else{
      this.service.getSearchItems(this.searchitem).subscribe((data : any)=>{
        this.items = data;
        if(this.items.length == 0){
          this.sResult = false;
          this.searching = false;          
        }
      });
      this.isSearch = false;     
    }    
    this.isUserLoggedIn = this.service.isUserLoggedIn;
  }

  onSubmitSearch(){
    this.searching = true;
    this.service.isSearch = true;  
    this.ngOnInit();
  }

  addItemToCart(item : Item){    
    this.cartItem.user_id = this.user.id;
    this.cartItem.items.push(item);
    localStorage.setItem('cartitems', JSON.stringify(this.cartItem));
    return this.service.addItemToCart(this.cartItem);
  }

  routeCart(){
    this.router.navigate(['cart']);
  }
}
