import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HomeServiceComponent } from '../home-service/home-service.component';
import { CartItem, Item } from '../Item';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  isUserLoggedIn : boolean;
  cartitems : CartItem;
  items : Item[];
  constructor(private service : HomeServiceComponent,
    private router : Router) { 
    this.isUserLoggedIn = false;
    this.cartitems = new CartItem();
    this.cartitems.items = [];
    this.items = this.cartitems.items;
  }

  ngOnInit(){
    this.isUserLoggedIn = this.service.isUserLoggedIn;
    this.cartitems = JSON.parse(localStorage.getItem('cartitems') || '{}');
    this.items = this.cartitems.items;
  }

  routeHome(){
    this.router.navigate(['home']);
  }

  routeStatus(){
    this.router.navigate(['status']);
  }
}
