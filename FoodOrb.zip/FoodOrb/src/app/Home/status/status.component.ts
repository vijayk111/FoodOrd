import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceComponent } from 'src/app/Authentication/auth-service/auth-service.component';
import { HomeServiceComponent } from '../home-service/home-service.component';

@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css']
})
export class StatusComponent implements OnInit {

  isUserLoggedIn : boolean;
  constructor(private service : HomeServiceComponent, private router : Router, 
    private authService : AuthServiceComponent) { 
    this.isUserLoggedIn = authService.isUserLoggedIn;
  }

  ngOnInit(): void {
  }

  routeHome(){
    this.router.navigate(['home']);
  }
}
