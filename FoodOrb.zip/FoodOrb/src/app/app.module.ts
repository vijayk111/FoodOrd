import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './Authentication/register/register.component';
import { LoginComponent } from './Authentication/login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ForgotPasswordComponent } from './Authentication/forgot-password/forgot-password.component';
import { HomeComponent } from './Home/home.component';
import { UserSettingsComponent } from './Home/user-settings/user-settings.component';
import { ProfileComponent } from './Home/profile/profile.component';
import { StatusComponent } from './Home/status/status.component';
import { PasswordMatchDirective } from './Authentication/register/pwdDirective';
import { HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './header/header.component';
import { CartComponent } from './Home/cart/cart.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    ForgotPasswordComponent,
    HomeComponent,
    UserSettingsComponent,
    ProfileComponent,
    StatusComponent,
    PasswordMatchDirective,
    HeaderComponent,
    CartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
