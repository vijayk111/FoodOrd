const express = require('express');
const fs = require('fs');

const app = express();
const port = 3000;

var data = new Array();

app.get('/employee/:id',function(req, res){
    var emp = JSON.parse(fs.readFileSync('first.json'));
    data = emp.employee;   
    console.log(data.find(req.params.id));
    if(data.length != 0){
        data.forEach(value => {
            if(value.id == req.params.id){
                emp = value;
            }
        });
    }else{
        emp = "There is no employee with that ID.";
    }    
    res.send(emp);
});

app.get('/project/:id', function(req,res){
    var proj = JSON.parse(fs.readFileSync('second.json'));
    data = proj.project;
    if(data.length != 0){
        data.forEach(value => {
            if(value.id == req.params.id){
                proj = value;
            }
        });
    }else{
        proj = "There is no project with that ID.";
    }    
    res.send(proj);
});

app.get('/getemployeedetails',function(req, res){
    
});

app.listen(port, () => {
    console.log(`Example app listening on port ${port}!`)
});