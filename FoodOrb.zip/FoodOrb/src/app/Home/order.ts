import { Item } from "./Item";

export class Order{
    orderid! : string;
    items! : Item[];
    totalcost! : number;
    status! : string;
    date! : Date;
}

export class UserCart{
    id! : number ;
    userid!:string;
    orders! : Order[] ;
    constructor(){
        this.userid="";
        this.orders = [];
    }
}