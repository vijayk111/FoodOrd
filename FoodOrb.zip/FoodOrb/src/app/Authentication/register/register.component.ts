import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthServiceComponent } from '../auth-service/auth-service.component';
import { user, User } from '../User';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  submitted: boolean = false;
  user : User ;
  model : user;
  confirmPassword : string = "";
  isUserLoggedIn : boolean = false;
  constructor(private service : AuthServiceComponent, private router : Router) {
    this.user = {
      id : "",
      name : "",
      email : "",
      password : "",
      address : [],
      prof : "",
      phone : 0
    }
    this.model = new user();
  }

  ngOnInit(){
  }

  onSubmit(){
    this.submitted = true;  
    this.service.registerUser(this.user).subscribe(data => {
        localStorage.setItem('user', JSON.stringify(data));
        this.router.navigate(['/home']);
    });
  }
  
}