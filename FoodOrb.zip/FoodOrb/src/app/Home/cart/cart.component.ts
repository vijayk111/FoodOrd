import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceComponent } from 'src/app/Authentication/auth-service/auth-service.component';
import { HomeServiceComponent } from '../home-service/home-service.component';
import { Item } from '../Item';
import { Order } from '../order';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  
  isUserLoggedIn : boolean;
  items : Item[];
  totalCost : number;
  err : string;
  errFlag : boolean;
  orFlag : boolean;
  order : Order;
  constructor(private service : HomeServiceComponent, private authService : AuthServiceComponent,
    private router : Router) { 
    this.isUserLoggedIn = this.authService.isUserLoggedIn;
    this.items = [];
    this.totalCost = 0;
    this.err = "Can't place Order since your Cart is empty";
    this.errFlag = false;
    this.order = new Order();
    this.orFlag = false;
  }

  ngOnInit(){
    this.isUserLoggedIn = this.authService.isUserLoggedIn;
    this.items = this.service.items;
    if(this.items.length != 0){
      this.items.forEach((element : Item)=>{
        this.totalCost = this.totalCost + element.cost;
      });
      this.errFlag = false;
    }
    this.orFlag = false;    
  }

  routeHome(){
    this.router.navigate(['home']);
  }

  routeStatus(){
    if(this.totalCost != 0){      
      this.order.orderid = Math.random().toString(35).substring(7);
      this.order.items = this.items;
      this.order.totalcost = this.totalCost;
      this.order.date = new Date();
      this.order.status="Placed!";
      this.items = [];
      this.totalCost = 0;
      this.service.items = [];
      this.service.placeOrder(this.order);
      this.orFlag = true;
    }else{
      this.errFlag = true;
      return;
    }
  }

  removeAllItems(){
    this.items = [];
    this.service.items = [];
    this.totalCost = 0;
    return;
  }
}
