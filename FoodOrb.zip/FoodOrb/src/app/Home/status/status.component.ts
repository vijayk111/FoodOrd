import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthServiceComponent } from 'src/app/Authentication/auth-service/auth-service.component';
import { HomeServiceComponent } from '../home-service/home-service.component';
import { Order, UserCart } from '../order';

@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css']
})
export class StatusComponent implements OnInit {

  isUserLoggedIn : boolean;
  orders : Order[];
  counter: { min: number, sec: number };
  orFlag : boolean;
  cancelFlag : boolean;
  orderM : Order;
  constructor(private service : HomeServiceComponent, private router : Router, 
    private authService : AuthServiceComponent, private modalService: NgbModal) { 
    this.isUserLoggedIn = this.authService.isUserLoggedIn;
    this.orders = [];    
    this.counter = { min: 0, sec: 0 };
    this.cancelFlag = true;
    this.orderM = new Order();
    this.orFlag = true;
  }

  ngOnInit(){    
    this.orders = this.service.userCart.orders;
    if(this.orders.length !==0){
      this.orFlag = false;
    }
  }

  startTimer() {
    this.counter = { min: 40, sec: 0 } // choose whatever you want
    let intervalId = setInterval(() => {
      if (this.counter.sec - 1 == -1) {
        this.counter.min -= 1;
        this.counter.sec = 59
      } 
      else this.counter.sec -= 1
      if (this.counter.min === 0 && this.counter.sec == 0) {
        clearInterval(intervalId);
        this.cancelFlag = false;
      }
    }, 1000)
  }

  routeHome(){
    this.router.navigate(['home']);
  }

  cancelOrder(order : Order){
    this.modalService.dismissAll();
    const i : number = this.service.userCart.orders.indexOf(order);
    if(i !== -1){
      this.service.userCart.orders.splice(i, 1);
    }
    return this.service.cancelOrder();
  }

  openModal(targetModal : any, order : Order) {
    this.modalService.open(targetModal, {
     centered: true,
     backdrop: 'static'
    });
    this.orderM = order;
   }
}
