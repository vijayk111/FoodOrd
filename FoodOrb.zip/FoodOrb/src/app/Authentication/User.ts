export class User{
    id! : string;
    name! : string;
    email! : string;
    password! : string; 
    address! : Address[];
    prof! : string;
    phone! : number;
}

export class user{
    id! : string;
    name! : string;
    email! : string;
    password! : string;
    confirmPassword! : string;
}

export class Address{
    addressType! :string;
    address! : string;
}