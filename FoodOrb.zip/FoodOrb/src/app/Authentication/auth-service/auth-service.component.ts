import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../User';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

@Injectable()
export class AuthServiceComponent implements OnInit {
 
  isUserLoggedIn : boolean;
  base_url : string = "http://localhost:3000/users";
  constructor(private httpClient: HttpClient) { 
    this.isUserLoggedIn = false;
  }

  ngOnInit(): void {
  }    
  
  registerUser(user: User):Observable<any>{
    const headers = { 'content-type': 'application/json'}
    user.id = "3";
    const url = this.base_url;
    const obj = JSON.stringify(user);
    return this.httpClient.post(url, obj,{'headers' : headers});
  }
  
  loginUser(user: User){
      const headers = { 'content-type': 'application/json'}
      const url=this.base_url+"?email="+user.email+"&"+user.password;
      return this.httpClient.get(url,{'headers' : headers});
  }  
}
