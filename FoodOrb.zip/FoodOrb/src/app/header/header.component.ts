import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceComponent } from '../Authentication/auth-service/auth-service.component';
import { User } from '../Authentication/User';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  isUserLoggedIn : boolean ;
  uname : string | null;
  user : User;
  constructor (private service: AuthServiceComponent, private router: Router) {
    this.isUserLoggedIn = this.service.isUserLoggedIn;
    this.user = JSON.parse(localStorage.getItem('user') || '{}')[0];
    this.uname = this.user.name;
  }
  ngOnInit(){
  }

  navigateTo(event : string){
    if(event){
      if(event == "logout"){
        this.isUserLoggedIn = false;
        this.service.isUserLoggedIn = false;
      }
      this.router.navigate([event]);
    }
  }

  routeHome(){
    this.router.navigate(["home"]);
  }

  routeCart(){
    this.router.navigate(["cart"]);
  }

  routeSettings(){
    this.router.navigate(["settings"]);
  }

  routeStatus(){
    this.router.navigate(["status"]);
  }

  routeProfile(){
    this.router.navigate(["profile"]);
  }

}
