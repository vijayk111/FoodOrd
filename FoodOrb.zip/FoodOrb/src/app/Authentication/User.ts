export class User{
    id! : string;
    name! : string;
    email! : string;
    password! : string; 
    address! : Address[];
    prof! : string;
    phone! : number;
}

export class user{
    id! : string;
    name! : string;
    email! : string;
    password! : string;
    confirmPassword! : string;
}

export class Address{
    addressid! : string | undefined;
    addressType! :string | undefined;
    address! : string | undefined;

    constructor(addressid ?: string, addressType ?: string, address ?: string){
        this.addressType = addressType;
        this.address = address;
        this.addressid = addressid;
    }
}