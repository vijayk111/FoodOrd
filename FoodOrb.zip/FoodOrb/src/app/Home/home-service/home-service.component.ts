import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthServiceComponent } from 'src/app/Authentication/auth-service/auth-service.component';
import { User } from 'src/app/Authentication/User';
import { Item } from '../Item';
import { Order, UserCart } from '../order';

@Injectable({
  providedIn: 'root'
})

export class HomeServiceComponent implements OnInit {

  user : User;
  item : Item;
  items : Array<Item>;
  userCart : UserCart;
  base_url : string ="http://localhost:3000/";  
  constructor(private httpClient: HttpClient, 
    private router: Router, private service : AuthServiceComponent) {
      this.user = new User();  
      this.items = [];
      this.item = new Item();   
      this.userCart = new UserCart();
      this.userCart.orders = [];
  }

  ngOnInit(){
  }

  getAllItems(){
    const headers = { 'content-type': 'application/json'};
    const url = this.base_url+"items";
    return this.httpClient.get(url,{'headers' : headers});
  }

  getSearchItems(searchItem : string){
    const headers = {'content-type' : 'application/json'};
    const url = this.base_url+"items?item_name_like="+searchItem;
    console.log(url);
    return this.httpClient.get(url, {'headers': headers});
  }

  addAddress(user : User){
    const headers = { 'content-type': 'application/json'};
    const url =this.base_url+"users/"+user.id;
    const obj = JSON.stringify(user); 
    console.log(this.user.id);
    return this.httpClient.put(url, user, {'headers': headers}).subscribe(data=>{
      this.user = JSON.parse(JSON.stringify(data));
    });
  }

  addItemToCart(item : Item){
    this.items.push(item);
  }

  placeOrder(order : Order){
    const headers = { 'content-type': 'application/json'};
    const url =this.base_url+"usercart";
    this.userCart.userid = this.user.id;
    this.userCart.orders.push(order);
    const obj = JSON.stringify(this.userCart);
    return this.httpClient.get(url).subscribe((data : any)=>{
      let i : number = 0;
      data.forEach((ele : UserCart) => {
        if(ele.userid == this.user.id){
          i = 1;
        }
      });
      if(i == 0){
        this.httpClient.post(this.base_url+"usercart",obj, {'headers': headers}).subscribe(data=>{
          this.userCart = JSON.parse(JSON.stringify(data));
        });        
      }else{
        this.httpClient.put(url+"/"+this.userCart.id, obj,{'headers': headers}).subscribe(data=>{
          this.userCart = JSON.parse(JSON.stringify(data));
        });
      }
    });
  }

 //since id is created randomly by json server, cannot request particular item. So access insecure way of item from all items
 getPlacedOrders() {  
 const url = this.base_url + "usercart";
    return this.httpClient.get(url).subscribe((data : any)=>{      
      data.forEach((ele : UserCart) => {
        if(ele.userid == this.user.id){
          this.userCart = ele;
        }
        return this.userCart.orders;
      });
    });
  }

  cancelOrder(){
    const headers = { 'content-type': 'application/json'};
    const url =this.base_url+"usercart/";
    const obj = JSON.stringify(this.userCart);
    this.httpClient.put(url+this.userCart.id, obj,{'headers': headers}).subscribe(data=>{
      this.userCart = JSON.parse(JSON.stringify(data));
    });
  }

}
