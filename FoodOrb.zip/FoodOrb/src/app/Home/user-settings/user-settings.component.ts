import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthServiceComponent } from 'src/app/Authentication/auth-service/auth-service.component';
import { Address, User } from 'src/app/Authentication/User';
import { HomeServiceComponent } from '../home-service/home-service.component';

@Component({
  selector: 'app-user-settings',
  templateUrl: './user-settings.component.html',
  styleUrls: ['./user-settings.component.css']
})
export class UserSettingsComponent implements OnInit {

  isUserLoggedIn : boolean;
  user : User;
  address : Address[];
  adClass : Address;
  constructor(private service : HomeServiceComponent, private router : Router,
    private authService : AuthServiceComponent, private modalService : NgbModal) { 
    this.isUserLoggedIn = authService.isUserLoggedIn;
    this.user = this.service.user;
    this.address = this.user.address;
    this.adClass = new Address();
  }

  ngOnInit() {
    this.address = this.user.address;
  }

  showDiv = {
    card : false,
    address : false
  }

  showAddressDiv = {
    list : true,
    addAds : false
  }

  onAdSubmit(form : NgForm){
    this.user.address.push(new Address(Math.random().toString(32).substring(8),
    form.value.addressType, form.value.address));   
    this.showAddressDiv.list = true;
    this.showAddressDiv.addAds=false;
    return this.service.addAddress(this.user);
  }

  onEditSubmit(form : NgForm, ad : Address){ 
    this.user.address.forEach((el : Address)=>{
      if(el.addressid == ad.addressid){
        el.addressType = form.value.addressType;
        el.address = form.value.address;
      }
    });
    this.modalService.dismissAll();
    this.showAddressDiv.list = true;
    this.showAddressDiv.addAds=false;
    return this.service.addAddress(this.user);
  }
  
  delAddress(ad : Address){
    const i : number = this.user.address.indexOf(ad);
    if(i !== -1){
      this.user.address.splice(i, 1);
    }
    return this.service.addAddress(this.user);
  }

  openModal(targetModal : any, ad : Address) {
    this.modalService.open(targetModal, {
     centered: true,
     backdrop: 'static'
    });
    this.adClass = ad;
   }
}
