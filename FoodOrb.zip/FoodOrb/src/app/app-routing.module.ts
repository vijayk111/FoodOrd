import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForgotPasswordComponent } from './Authentication/forgot-password/forgot-password.component';
import { LoginComponent } from './Authentication/login/login.component';
import { RegisterComponent } from './Authentication/register/register.component';
import { CartComponent } from './Home/cart/cart.component';
import { HomeComponent } from './Home/home.component';
import { ProfileComponent } from './Home/profile/profile.component';
import { StatusComponent } from './Home/status/status.component';
import { UserSettingsComponent } from './Home/user-settings/user-settings.component';

const routes: Routes = [
  { path : '', redirectTo : "/register", pathMatch : 'full' },
  { path : "login", component: LoginComponent },
  { path : "register", component: RegisterComponent },
  { path : "forgotPwd", component: ForgotPasswordComponent },
  { path : "home", component: HomeComponent },
  { path : "logout", component: LoginComponent },
  { path : "profile", component: ProfileComponent },
  { path : "cart", component: CartComponent },
  { path : "settings", component: UserSettingsComponent },
  { path : "status", component: StatusComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
