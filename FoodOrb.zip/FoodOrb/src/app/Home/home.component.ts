import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthServiceComponent } from '../Authentication/auth-service/auth-service.component';
import { User } from '../Authentication/User';
import { HomeServiceComponent } from './home-service/home-service.component';
import { Item } from './Item';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  user : User;
  items : Item[];
  modalItem : Item; 
  isUserLoggedIn : boolean;
  searching : boolean;
  searchitem : string ;
  constructor(private service : HomeServiceComponent, private router : Router, 
    private authService : AuthServiceComponent, private modalService: NgbModal) {   
    this.user = this.service.user;
    this.items = [];
    this.modalItem = new Item(); 
    this.isUserLoggedIn =  this.authService.isUserLoggedIn; ;
    this.searchitem = "";
    this.searching = true;
  }

  ngOnInit(){    
    this.isUserLoggedIn = this.authService.isUserLoggedIn;
    this.user = this.service.user;
    this.service.getAllItems().subscribe((data : any) =>{
        this.items = data;
    });
    this.service.getPlacedOrders(); 
  }

  showBackBtn = {
    showbtn : false
  }

  onSubmitSearch(){
    return this.service.getSearchItems(this.searchitem).subscribe((data : any)=>{
      this.items = data;      
      this.showBackBtn.showbtn = true;  
      if(this.items.length == 0){
        this.searching = false;          
      }
    });
  }

  routeBack(searchForm : NgForm){
    this.showBackBtn.showbtn = false;
    this.searching = true;  
    searchForm.resetForm();
    this.ngOnInit();
  }

  addItemToCart(item : Item){    
    this.modalService.dismissAll();
    return this.service.addItemToCart(item);
  }

  routeCart(){
    this.router.navigate(['cart']);
  }

  openModal(targetModal : any, item : Item) {
    this.modalService.open(targetModal, {
     centered: true,
     backdrop: 'static'
    });
    this.modalItem = item;
   }
}
