import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceComponent } from 'src/app/Authentication/auth-service/auth-service.component';
import { User } from 'src/app/Authentication/User';
import { CartItem, Item } from '../Item';

@Injectable({
  providedIn: 'root'
})

export class HomeServiceComponent implements OnInit {

  isUserLoggedIn : boolean;
  isSearch : boolean;
  base_url : string ="http://localhost:3000/";
  constructor(private httpClient: HttpClient, 
    private router: Router, private service : AuthServiceComponent) {
      this.isUserLoggedIn = this.service.isUserLoggedIn;
      this.isSearch = false;
  }

  ngOnInit(): void {
  }

  getAllItems(){
    const headers = { 'content-type': 'application/json'};
    const url = this.base_url+"items";
    return this.httpClient.get(url,{'headers' : headers});
  }

  getSearchItems(searchItem : string){
    const headers = {'content-type' : 'application/json'};
    const url = this.base_url+"items?search="+searchItem;
    console.log(url);
    return this.httpClient.get(url, {'headers': headers});
  }

  addAddress(user : User){
    const headers = { 'content-type': 'application/json'};
    const url = this.base_url+"users";
    return this.httpClient.put(url,{'headers' : headers});
  }

  addItemToCart(item : CartItem){
    const headers = { 'content-type': 'application/json'};
    const url = this.base_url+"cartitems";
    const obj = JSON.stringify(item);
    return this.httpClient.post(url, obj, {'headers' : headers});
  }
}
