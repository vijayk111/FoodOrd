export class Item{
    id! : string;
    item_name! : string;
    img_url! : string;
    res_name! : string;
    res_type! : string;
    cost! : number;
    rating! : number;  
}

export class CartItem{
    user_id! : string;
    items! : Item[];
}