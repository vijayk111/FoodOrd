import { Component, OnInit } from '@angular/core';
import { AuthServiceComponent } from '../auth-service/auth-service.component';
import { user, User } from '../User';
import { Router } from '@angular/router';
import { HomeServiceComponent } from 'src/app/Home/home-service/home-service.component';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  submitted: boolean = false;
  user : User ;
  model : user;
  confirmPassword : string = "";
  constructor(private service : AuthServiceComponent, private router : Router, 
    private homeService : HomeServiceComponent) {
    this.user = {
      id : "",
      name : "",
      email : "",
      password : "",
      address : [],
      prof : "",
      phone : 0
    }
    this.model = new user();
  }

  ngOnInit(){
    localStorage.removeItem("user_id");
    localStorage.removeItem("user_name");
    localStorage.removeItem("username");
    localStorage.removeItem("user");
    this.homeService.items= [];
  }

  onSubmit(){
    this.submitted = true;
    this.service.registerUser(this.user).subscribe(data => {
        this.service.isUserLoggedIn = true;
        this.homeService.user = JSON.parse(JSON.stringify(data));
        this.router.navigate(['/home']);
    });
  }
  
}