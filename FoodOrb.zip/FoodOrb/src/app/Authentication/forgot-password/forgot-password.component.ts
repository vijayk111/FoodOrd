import { Component, OnInit } from '@angular/core';
import { User } from '../User';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  user : User;
  submitted: boolean = false;
  constructor() {
    this.user = {
      id : "",
      name : "",
      email : "",
      password : "",
      address : [],
      prof : "",
      phone : 0
    } 
  }

  ngOnInit(){
  }

  onSubmit(){
    this.submitted = true;
    console.log(this.user.email);
  }
}
